---
title: Bengaluru Router
emoji: 🌍
colorFrom: blue
colorTo: purple
sdk: gradio
sdk_version: 6.10.0
app_file: app.py
pinned: false
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
